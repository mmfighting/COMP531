# COMP431/531 Demo Surge Hosted Site

This is a simple site with static html pages

